import cv2
import numpy as np
from deepface import DeepFace

def preprocess_image(img_path):
    """
    預處理圖片：讀取圖片、檢測並裁切臉部區域。
    若未檢測到臉部，返回原始圖片。
    """
    image = cv2.imread(img_path)
    if image is None:
        raise ValueError("無法讀取圖片檔案")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    face_cascade = cv2.CascadeClassifier(cascade_path)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    if len(faces) > 0:
        (x, y, w, h) = faces[0]
        cropped = image[y:y+h, x:x+w]
        return cropped
    else:
        return image

def analyze_face(img_path, method="deepface"):
    """
    分析圖片或影片並返回情緒、性別、種族與年齡結果。
    支援模式：
      - deepface：使用 DeepFace 分析靜態圖片（標準模式）
      - refined：僅回傳完整情緒分佈（精細模式）
      - video：對影片取多幀平均結果
    返回:
      - tuple: ([主導情緒, 主導性別, 主導種族, 年齡], 圖表數據)
    """
    if method == "video":
        return analyze_video(img_path)
    elif method == "refined":
        return analyze_deepface_refined(img_path)
    else:
        return analyze_deepface(img_path)

def analyze_deepface(img_path):
    try:
        # 先進行預處理：裁切臉部區域
        preprocessed_img = preprocess_image(img_path)
        # 使用 retinaface 後端提升臉部檢測準確度
        result = DeepFace.analyze(
            img_path=preprocessed_img,
            actions=["emotion", "gender", "race", "age"],
            enforce_detection=False,
            detector_backend="retinaface"
        )
    except Exception as e:
        print(f"初次 DeepFace.analyze 失敗: {e}")
        try:
            print("嘗試手動建立 DeepFace Emotion 模型...")
            model = DeepFace.build_model("emotion")
            try:
                model.build(input_shape=(None, 48, 48, 3))
            except Exception as build_e:
                print(f"模型 build() 調用失敗 (可能不支援): {build_e}")
            dummy_input = np.zeros((1, 48, 48, 3))
            model.predict(dummy_input)
            result = DeepFace.analyze(
                img_path=preprocessed_img,
                actions=["emotion", "gender", "race", "age"],
                enforce_detection=False,
                detector_backend="retinaface"
            )
        except Exception as e2:
            raise ValueError(f"DeepFace 分析失敗: {str(e2)}")
    try:
        emotion_scores = result[0]['emotion']
        dominant_emotion = max(emotion_scores, key=emotion_scores.get)
        gender_scores = result[0]['gender']
        dominant_gender = max(gender_scores, key=gender_scores.get)
        race_scores = result[0]['race']
        dominant_race = max(race_scores, key=race_scores.get)
        age = result[0]['age']
        dominant_list = [dominant_emotion, dominant_gender, dominant_race, age]
        graph_data = [emotion_scores, gender_scores, race_scores, age]
        return dominant_list, graph_data
    except Exception as e:
        raise ValueError(f"DeepFace 分析失敗: {str(e)}")

def analyze_deepface_refined(img_path):
    """
    回傳完整情緒分佈資訊，便於進行更精細的分析。
    ※ 若您不需要此模式，可考慮移除此函式以精簡程式碼。
    """
    try:
        preprocessed_img = preprocess_image(img_path)
        result = DeepFace.analyze(
            img_path=preprocessed_img,
            actions=["emotion"],
            enforce_detection=False,
            detector_backend="retinaface"
        )
    except Exception as e:
        print(f"初次 refined DeepFace.analyze 失敗: {e}")
        try:
            print("嘗試手動建立 DeepFace Emotion 模型 (refined)...")
            model = DeepFace.build_model("emotion")
            try:
                model.build(input_shape=(None, 48, 48, 3))
            except Exception as build_e:
                print(f"模型 build() 失敗 (refined): {build_e}")
            dummy_input = np.zeros((1, 48, 48, 3))
            model.predict(dummy_input)
            result = DeepFace.analyze(
                img_path=preprocessed_img,
                actions=["emotion"],
                enforce_detection=False,
                detector_backend="retinaface"
            )
        except Exception as e2:
            raise ValueError(f"Refined DeepFace 分析失敗: {str(e2)}")
    try:
        emotion_scores = result[0]['emotion']
        dominant_emotion = max(emotion_scores, key=emotion_scores.get)
        dominant_list = [dominant_emotion, "未知", "未知", "未知"]
        graph_data = [emotion_scores, None, None, None]
        return dominant_list, graph_data
    except Exception as e:
        raise ValueError(f"Refined DeepFace 分析失敗: {str(e)}")

def analyze_video(video_path, sample_rate=10):
    """
    ※ 此函式用於影片分析，目前主流程未使用。
    若未來需支援影片，可保留，否則可考慮移除。
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError("無法開啟影片檔案。")
    emotion_scores_list = []
    frame_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_count % sample_rate == 0:
            try:
                dominant_list, graph_data = analyze_deepface_from_frame(frame)
                emotion_scores = graph_data[0]
                emotion_scores_list.append(emotion_scores)
            except Exception as e:
                print(f"幀 {frame_count} 分析失敗: {e}")
        frame_count += 1
    cap.release()
    if not emotion_scores_list:
        raise ValueError("未能從影片中提取有效情緒數據。")
    combined_emotions = {}
    keys = emotion_scores_list[0].keys()
    for key in keys:
        combined_emotions[key] = np.mean([scores.get(key, 0) for scores in emotion_scores_list])
    dominant_emotion = max(combined_emotions, key=combined_emotions.get)
    dominant_list = [dominant_emotion, "未知", "未知", "未知"]
    graph_data = [combined_emotions, None, None, None]
    return dominant_list, graph_data

def analyze_deepface_from_frame(frame):
    """
    ※ 此函式為影片每幀的分析輔助函式，目前僅供 analyze_video 使用。
    """
    temp_path = "temp_frame.jpg"
    cv2.imwrite(temp_path, frame)
    return analyze_deepface(temp_path)
