import cv2
import os
import datetime

def take_selfie(save_dir="/Users/zhanganrou/Desktop/selfies"):
    """
    使用電腦的前置攝影機自拍，並將照片儲存到指定的資料夾。
    :param save_dir: 照片儲存的目錄，預設為[ /Users/zhanganrou/Desktop/selfies ]<--請更改為你電腦的
    :return: 照片的完整路徑
    """
       # 確保儲存目錄存在
    os.makedirs(save_dir, exist_ok=True)
    
    # 開啟攝影機 (0 通常是內建攝影機)
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("無法開啟攝影機！")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("無法讀取攝影機影像！")
            break
        
        # 顯示即時畫面
        cv2.imshow("按下空白鍵拍照，ESC退出", frame)
        key = cv2.waitKey(1) & 0xFF
        
        # 按下空白鍵拍照
        if key == 32:  # 空白鍵的 ASCII 碼
            break
        # 按下 ESC 鍵退出
        elif key == 27:  # ESC 鍵的 ASCII 碼
            cap.release()
            cv2.destroyAllWindows()
            return None
    
    cap.release()
    cv2.destroyAllWindows()
    
    # 產生時間戳作為檔名
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"selfie_{timestamp}.jpg"
    file_path = os.path.join(save_dir, filename)
    
    # 儲存影像
    cv2.imwrite(file_path, frame)
    
    return file_path

if __name__ == "__main__":
    path = take_selfie()
    if path:
        print(f"自拍已儲存至: {path}")
    else:
        print("拍攝取消")