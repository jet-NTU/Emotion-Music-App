import openai

openai.api_key = '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'

def format_emotion_scores(emotion_scores):
    """
    將情緒分數字典格式化為多行文字，以便在提示語中呈現
    """
    formatted = "\n".join([f"{emotion}: {score}%" for emotion, score in emotion_scores.items()])
    return formatted

def get_song_recommendation(emotion_scores, music_preferences, language_preferences):
    """
    根據完整的情緒分數、音樂喜好與語言偏好推薦一首獨特且個性化的歌曲
    """
    # 格式化情緒數據以提供更多細節
    emotion_details = format_emotion_scores(emotion_scores)
    
    prompt = (
        f"以下是使用者的情緒分析結果：\n{emotion_details}\n\n"
        f"使用者的音樂喜好：{music_preferences}\n"
        f"語言偏好：{language_preferences}\n\n"
        "請根據上述資訊推薦一首獨特且個性化的歌曲，並解釋這些情緒數據如何影響歌曲風格或氛圍。"
        "請依照以下格式回覆，不要包含其他文字：\n"
        "歌手: <歌手名>\n歌曲名: <歌曲名>"
    )
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "你是一个音樂推薦專家，請根據情緒數據和偏好做出細緻推薦。"},
                {"role": "user", "content": prompt}
            ]
        )
        song = response.choices[0].message['content'].strip()
        return song
    except Exception as e:
        print(f"API 錯誤: {e}")
        return None

# 使用範例：
if __name__ == "__main__":
    # 假設從情緒分析獲得以下分數
    emotions = {"快樂": 70, "悲傷": 20, "驚訝": 10}
    music_pref = "搖滾, 輕快"
    lang_pref = "英文"
    
    recommendation = get_song_recommendation(emotions, music_pref, lang_pref)
    print(recommendation)
