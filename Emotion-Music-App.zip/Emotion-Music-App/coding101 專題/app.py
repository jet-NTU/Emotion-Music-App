import os
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from analyze_module import analyze_face  # 從先前的情緒分析模組引用
from song_recommendation_module import get_song_recommendation  # 從歌曲推薦模組引用

app = Flask(__name__)
UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/api/analyze', methods=['POST'])
def analyze():
    # 檢查是否有上傳圖片
    if 'image' not in request.files:
        return jsonify({'error': '未提供圖片'}), 400
    image = request.files['image']
    if image.filename == '':
        return jsonify({'error': '未選擇檔案'}), 400

    filename = secure_filename(image.filename)
    image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    image.save(image_path)
    
    # 取得偏好資訊（未輸入則給預設值）
    music_preferences = request.form.get('music_preferences', '流行')
    language_preferences = request.form.get('language_preferences', '中文, 英文')
    
    try:
        # 分析圖片，取得情緒分析結果（dominant_list 與 graph_data）
        dominant_list, graph_data = analyze_face(image_path)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

    # 以情緒分數（graph_data[0]）傳入歌曲推薦模組
    emotion_scores = graph_data[0]
    song = get_song_recommendation(emotion_scores, music_preferences, language_preferences)
    
    return jsonify({
        'dominant': dominant_list,
        'emotion_scores': emotion_scores,
        'song_recommendation': song
    })

# 提供靜態檔案服務，作為 PWA 前端
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists("static/" + path):
        return send_from_directory("static", path)
    else:
        return send_from_directory("static", "index.html")

if __name__ == '__main__':
    app.run(debug=True)
