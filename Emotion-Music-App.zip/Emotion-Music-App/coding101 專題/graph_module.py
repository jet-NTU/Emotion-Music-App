import matplotlib.pyplot as plt

def show_graph(data):
    """
    根據分析結果生成圖表。
    
    參數:
    - data (list): 包含 [emotion_scores, gender_scores, race_scores, age] 的列表
    """
    emotion_scores, gender_scores, race_scores, age = data

    # 創建子圖
    fig, axs = plt.subplots(2, 2, figsize=(10, 8))

    # 情緒分析圖
    axs[0, 0].bar(emotion_scores.keys(), emotion_scores.values(), color='skyblue')
    axs[0, 0].set_title("情緒分析", fontname="微軟雅黑")
    axs[0, 0].set_xlabel("情緒", fontname="微軟雅黑")
    axs[0, 0].set_ylabel("得分 (%)", fontname="微軟雅黑")

    # 性別分析圖
    axs[0, 1].bar(gender_scores.keys(), gender_scores.values(), color='lightcoral')
    axs[0, 1].set_title("性別分析", fontname="微軟雅黑")
    axs[0, 1].set_xlabel("性別", fontname="微軟雅黑")
    axs[0, 1].set_ylabel("得分 (%)", fontname="微軟雅黑")

    # 種族分析圖
    axs[1, 0].bar(race_scores.keys(), race_scores.values(), color='lightgreen')
    axs[1, 0].set_title("種族分析", fontname="微軟雅黑")
    axs[1, 0].set_xlabel("種族", fontname="微軟雅黑")
    axs[1, 0].set_ylabel("得分 (%)", fontname="微軟雅黑")

    # 年齡顯示
    axs[1, 1].text(0.5, 0.5, f"年齡: {age}", fontsize=16, ha='center', va='center', color='purple', fontname="微軟雅黑")
    axs[1, 1].set_title("年齡分析", fontname="微軟雅黑")
    axs[1, 1].axis('off')

    # 調整布局
    plt.tight_layout()

    # 顯示圖表
    plt.show()
