import sys
import logging
import re
import webbrowser
import cv2
import os
import datetime
from PyQt5.QtWidgets import (QApplication, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
                             QWidget, QFileDialog, QMainWindow, QLineEdit, QComboBox, QMessageBox)
from PyQt5.QtGui import QPixmap, QIcon, QFont, QStandardItem, QStandardItemModel
from PyQt5.QtCore import Qt, QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import all  # 整合分析模組
import song_recommendation_module

logging.basicConfig(level=logging.DEBUG, filename='emotion_analyzer.log', filemode='w',
                    format='%(asctime)s - %(levelname)s - %(message)s')

SAVE_DIR = './selfies'
os.makedirs(SAVE_DIR, exist_ok=True)


def take_selfie_with_countdown(save_dir=SAVE_DIR):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("無法開啟攝影機！")

    print("倒數開始...")
    for i in range(10, 0, -1):
        ret, frame = cap.read()
        if not ret:
            cap.release()
            cv2.destroyAllWindows()
            raise RuntimeError("攝影機影像讀取失敗！")
        cv2.putText(frame, str(i), (250, 250), cv2.FONT_HERSHEY_SIMPLEX, 5, (0, 0, 255), 5)
        cv2.imshow("倒數拍照", frame)
        cv2.waitKey(1000)

    ret, frame = cap.read()
    cap.release()
    cv2.destroyAllWindows()

    if not ret:
        raise RuntimeError("攝影機影像讀取失敗！")

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = os.path.join(save_dir, f"selfie_{timestamp}.jpg")
    cv2.imwrite(file_path, frame)

    return file_path


class CheckableComboBox(QComboBox):
    def __init__(self, parent=None):
        super(CheckableComboBox, self).__init__(parent)
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().setPlaceholderText("請選擇語言")
        self.setModel(QStandardItemModel(self))
        self.view().pressed.connect(self.handleItemPressed)
        self.model().dataChanged.connect(self.updateText)

    def addItem(self, text, data=None):
        item = QStandardItem(text)
        item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
        item.setData(Qt.Unchecked, Qt.CheckStateRole)
        self.model().appendRow(item)

    def handleItemPressed(self, index):
        item = self.model().itemFromIndex(index)
        item.setCheckState(Qt.Unchecked if item.checkState() == Qt.Checked else Qt.Checked)

    def updateText(self):
        selected = [self.model().item(index).text() for index in range(self.model().rowCount()) 
                    if self.model().item(index).checkState() == Qt.Checked]
        self.lineEdit().setText(", ".join(selected))


class MatplotlibCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(6, 4), dpi=100)
        self.axes = fig.add_subplot(111)
        super().__init__(fig)

    def plot_emotions(self, emotion_data):
        self.axes.clear()
        emotions, percentages = zip(*emotion_data.items())
        self.axes.bar(emotions, percentages, color='skyblue')
        self.draw()


class EmotionAnalyzerUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("情緒分析與音樂推薦")
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowIcon(QIcon("icon.png"))

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)

        self.image_label = QLabel("請上傳圖片或自拍", self)
        self.image_label.setFont(QFont("Microsoft YaHei", 12))
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setFixedSize(400, 400)
        self.image_label.setStyleSheet("border: 1px solid #ccc; background-color: #eee;")
        self.layout.addWidget(self.image_label, alignment=Qt.AlignCenter)

        self.graph_canvas = MatplotlibCanvas(self)
        self.layout.addWidget(self.graph_canvas)

        self.music_label = QLabel("推薦音樂: 無", self)
        self.music_label.setAlignment(Qt.AlignCenter)
        self.music_label.setFont(QFont("Microsoft YaHei", 12))
        self.music_label.setWordWrap(True)
        self.layout.addWidget(self.music_label)

        self.genre_input = QLineEdit(self)
        self.genre_input.setPlaceholderText("輸入喜歡的曲風")
        self.layout.addWidget(self.genre_input)

        self.language_combo = CheckableComboBox(self)
        for lang in ["中文", "英文", "日文", "韓文", "西班牙文", "法文", "德文"]:
            self.language_combo.addItem(lang)
        # 清除預設選取，讓 QLineEdit 保持空白
        self.language_combo.setCurrentIndex(-1)
        self.layout.addWidget(self.language_combo)

        self.upload_button = QPushButton("選擇圖片")
        self.upload_button.clicked.connect(self.handle_upload)
        self.layout.addWidget(self.upload_button)

        self.selfie_button = QPushButton("自拍分析")
        self.selfie_button.setStyleSheet("background-color: #0078d7; color: white;")
        self.selfie_button.clicked.connect(self.handle_selfie)
        self.layout.addWidget(self.selfie_button)

    def is_language_selected(self):
        """檢查是否有選擇語言（任何項目的勾選狀態為 Checked 即視為已選擇）"""
        for index in range(self.language_combo.model().rowCount()):
            item = self.language_combo.model().item(index)
            if item.checkState() == Qt.Checked:
                return True
        return False

    def handle_upload(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "選擇圖片", "", "Images (*.png *.jpg *.jpeg)")
        if file_path:
            self.analyze_image(file_path)

    def handle_selfie(self):
        try:
            file_path = take_selfie_with_countdown()
            self.analyze_image(file_path)
        except Exception as e:
            logging.error(f"自拍錯誤: {e}")
            self.image_label.setText(f"錯誤: {e}")

    def analyze_image(self, img_path):
        # 檢查是否同時未輸入曲風和未選語言
        if not self.genre_input.text().strip() and not self.is_language_selected():
            reply = QMessageBox.question(self, '音樂偏好未選擇',
                                         '您未選擇音樂曲風與語言，是否要繼續並使用預設設定？',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if reply == QMessageBox.No:
                return
        try:
            genre = self.genre_input.text().strip() if self.genre_input.text().strip() else "流行"
            # 如果有選擇語言，就從 QLineEdit 取得文字，否則使用預設值
            language = self.language_combo.lineEdit().text().strip() if self.is_language_selected() else "中文, 英文"
            emotions, graph_data, song_info = all.analyze_and_recommend(img_path, genre, language)

            pixmap = QPixmap(img_path)
            self.image_label.setPixmap(pixmap.scaled(400, 400, Qt.KeepAspectRatio))
            self.graph_canvas.plot_emotions(graph_data[0])

            artist, song, url, _ = song_info
            self.music_label.setText(f"推薦音樂: {artist} - {song}")
            if url:
                webbrowser.open(url)
            else:
                QMessageBox.warning(self, '未找到影片', '無法在 YouTube 上找到對應的音樂影片，將重新生成推薦歌曲。')
                self.analyze_image(img_path)
        except Exception as e:
            logging.error(f"分析錯誤: {e}")
            self.image_label.setText(f"錯誤: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = EmotionAnalyzerUI()
    window.show()
    sys.exit(app.exec_())
