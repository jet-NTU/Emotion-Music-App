import yt_dlp

def search_youtube(song_name, artist_name):
    """
    根據歌曲名和歌手名在 YouTube 上進行搜索，並返回一個 tuple：
      (video_url, video_title)
    若找不到符合的影片，回傳 None
    """
    search_query = f"{song_name} {artist_name}"
    ydl_opts = {
        'quiet': True,
        # 不使用 extract_flat 以獲得完整資訊
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        result = ydl.extract_info(f"ytsearch:{search_query}", download=False)
        if result and 'entries' in result and len(result['entries']) > 0:
            video_info = result['entries'][0]
            video_url = video_info.get('webpage_url', None)
            video_title = video_info.get('title', None)
            if video_url:
                return (video_url, video_title)
        return None
