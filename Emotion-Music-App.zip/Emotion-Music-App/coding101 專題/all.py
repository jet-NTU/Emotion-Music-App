import os
import analyze_module
import song_recommendation_module
import youtube_search_module
import webbrowser
import tensorflow as tf

os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

def analyze_and_recommend(img_path, music_preferences="流行", language_preferences="中文"):
    if not os.path.exists(img_path):
        raise FileNotFoundError("指定的圖片文件不存在。")

    dominant_list, graph_data = analyze_module.analyze_face(img_path, method="fer")

    if not dominant_list or len(dominant_list) == 0:
        raise ValueError("無法提取主導情緒。")
    emotions = dominant_list[0]

    song = song_recommendation_module.get_song_recommendation(emotions, music_preferences, language_preferences)
    if not song:
        raise ValueError("無法根據情緒獲得歌曲推薦。")

    lines = song.split("\n")
    if len(lines) < 2:
        raise ValueError("歌曲推薦格式錯誤，缺少歌手或歌曲名稱。")

    artist_name = lines[0].replace("歌手: ", "").strip()
    song_name = lines[1].replace("歌曲名: ", "").strip()

    video_info = youtube_search_module.search_youtube(song_name, artist_name)
    if not video_info:
        raise ValueError("無法在 YouTube 上找到相關視頻。")
    video_url, video_title = video_info

    return emotions, graph_data, (artist_name, song_name, video_url, video_title)
