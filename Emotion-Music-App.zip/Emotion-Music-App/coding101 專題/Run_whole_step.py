import sys
from analyze_module import analyze_face
from graph_module import show_graph

if len(sys.argv) < 2:
    print("請提供圖片路徑作為參數，例如：python Run_whole_step.py path/to/image.jpg")
    sys.exit(1)

img_path = sys.argv[1]
while True:
    try:
        emotion_percentages, graph_data = analyze_face(img_path)
        print("主導情緒與分析數據：", emotion_percentages)
        show_graph(graph_data)
        break
    except Exception as e:
        print(f"Failed: {e}")
        break
